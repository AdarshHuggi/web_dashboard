import sqlite3
from flask import Flask, render_template, request

# ...existing code...
app = Flask(__name__)


sample_data = {
    'home': {
        'welcome_message': 'Welcome to the Report App!',
        'features': ['Easy reporting', 'Custom dashboards', 'Export to PDF']
    },
    'about': {
        'company': 'Report App Inc.',
        'mission': 'To simplify reporting for everyone.',
        'team': ['Alice', 'Bob', 'Charlie']
    },
    'contact': {
        'email': 'support@reportapp.com',
        'phone': '+1-800-555-1234',
        'address': '123 Main St, Springfield'
    }
}
@app.route('/')
def home():
    return render_template('home.html', title="Home")

@app.route('/about')
def about():
    return render_template('about.html', title="About")

@app.route('/contact')
def contact():
    return render_template('contact.html', title="Contact")





def get_db_connection():
    conn = sqlite3.connect('report_app.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/dashboard')
def dashboard():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    conn = get_db_connection()

    # Build WHERE clause for date filtering
    where_clause = ""
    params = []
    if from_date:
        where_clause += "date >= ?"
        params.append(from_date)
    if to_date:
        if where_clause:
            where_clause += " AND "
        where_clause += "date <= ?"
        params.append(to_date)
    if where_clause:
        where_clause = "WHERE " + where_clause

    cancelled_transactions = conn.execute(
        f"SELECT * FROM cancelled_transactions {where_clause} ORDER BY date DESC", params
    ).fetchall()
    rejected_orders = conn.execute(
        f"SELECT * FROM rejected_orders {where_clause} ORDER BY date DESC", params
    ).fetchall()
    null_order_reports = conn.execute(
        f"SELECT * FROM order_reports WHERE order_id IS NULL "
        + (f"AND date >= ? " if from_date else "")
        + (f"AND date <= ? " if to_date else "")
        + "ORDER BY date DESC",
        [d for d in [from_date, to_date] if d]
    ).fetchall()
    conn.close()
    return render_template(
        'dashboard.html',
        cancelled_transactions=cancelled_transactions,
        rejected_orders=rejected_orders,
        null_order_reports=null_order_reports
    )

if __name__ == '__main__':
    app.run(debug=True)

