import sqlite3
from faker import Faker
import random
from datetime import datetime, timedelta

fake = Faker()
conn = sqlite3.connect('report_app.db')
c = conn.cursor()

# Create tables
c.execute('''
CREATE TABLE IF NOT EXISTS cancelled_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    reason TEXT
)
''')
c.execute('''
CREATE TABLE IF NOT EXISTS rejected_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    reason TEXT
)
''')
c.execute('''
CREATE TABLE IF NOT EXISTS order_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    status TEXT,
    order_id INTEGER
)
''')

# Insert sample data
def random_date():
    return (datetime.now() - timedelta(days=random.randint(0, 365))).strftime('%Y-%m-%d')

c.executemany(
    'INSERT INTO cancelled_transactions (date, reason) VALUES (?, ?)',
    [(random_date(), fake.sentence(nb_words=6)) for _ in range(100)]
)
c.executemany(
    'INSERT INTO rejected_orders (date, reason) VALUES (?, ?)',
    [(random_date(), fake.sentence(nb_words=6)) for _ in range(100)]
)
# 50 with order_id, 50 with NULL
order_reports_data = []
for i in range(100):
    status = random.choice(['Pending', 'Completed', 'Failed'])
    order_id = None if i < 50 else random.randint(1000, 2000)
    order_reports_data.append((random_date(), status, order_id))
c.executemany(
    'INSERT INTO order_reports (date, status, order_id) VALUES (?, ?, ?)',
    order_reports_data
)

conn.commit()
conn.close()
print("Database initialized with sample data.")